const swiperMainPartner = new Swiper(".swiper.slider-partner", {
  direction: "horizontal",
  loop: true,
  allowTouchMove: true,
  autoplay: {
    delay: 2000,
    pauseOnMouseEnter: true,
  },
  breakpoints: {
    320: {
      slidesPerView: 1,
      spaceBetween: 30,
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 30,
    },
    992: {
      slidesPerView: 3,
      spaceBetween: 30,
    },
    1200: {
      slidesPerView: 4,
      spaceBetween: 30,
    },
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

document.addEventListener("DOMContentLoaded", function () {
  const menuToggle = document.querySelector(".mobile-header__menu");
  const mobileNav = document.querySelector(".mobile-header__nav");
  const mobileSearch = document.querySelector(".mobile-header__search-body");
  const mobileSearchBtn = document.querySelector(".mobile-header__search-btn");
  const mobileSearchCloseBtn = document.querySelector(
    ".mobile-header__search-close",
  );
  const mobileSearchContent = document.querySelector(".mobile-header__content");
  const mobileLogo = document.querySelector(".mobile-header__logo");
  const body = document.body;

  if (menuToggle) {
    menuToggle.addEventListener("click", function () {
      menuToggle.classList.toggle("open");
      mobileNav.classList.toggle("open");

      if (mobileSearch.classList.contains("open")) {
        mobileSearch.classList.remove("open");
      }

      if (mobileNav.classList.contains("open")) {
        body.classList.add("no-scroll");
      } else {
        body.classList.remove("no-scroll");
      }
    });
  }

  if (mobileSearchBtn) {
    mobileSearchBtn.addEventListener("click", function () {
      mobileSearch.classList.add("open");
      mobileLogo.classList.add("hidden");
      menuToggle.classList.add("hidden");
      mobileSearchBtn.classList.add("hidden");
      mobileSearchCloseBtn.classList.remove("hidden");
      mobileSearchContent.classList.add("w-100");
    });
  }

  if (mobileSearchCloseBtn) {
    mobileSearchCloseBtn.addEventListener("click", function () {
      mobileSearch.classList.remove("open");
      mobileLogo.classList.remove("hidden");
      menuToggle.classList.remove("hidden");
      mobileSearchBtn.classList.remove("hidden");
      mobileSearchCloseBtn.classList.add("hidden");
      mobileSearchContent.classList.remove("w-100");
    });
  }
});
